#pragma once
void testAll();

