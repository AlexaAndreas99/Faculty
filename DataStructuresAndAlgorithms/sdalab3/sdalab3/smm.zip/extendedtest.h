#pragma once
void testAllExtended();