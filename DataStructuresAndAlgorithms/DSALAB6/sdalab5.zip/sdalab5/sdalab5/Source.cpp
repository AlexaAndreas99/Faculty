#include <iostream>
#include <vector>
#include <algorithm>
#include <Windows.h>
#include "SecondPriorityqueue.h"
#include "test.h"

int main()
{
	testP6();	
	system("pause");
	return 0;
}