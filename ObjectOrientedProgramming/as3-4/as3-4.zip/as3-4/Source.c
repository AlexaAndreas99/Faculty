#include <stdio.h>
#include <string.h>

struct medication {
	char name[50];
	int concentration;
	int quantity;
	int price;
};

void print_all(struct medication *repo, int n)
{	
	int i;
	for (i = 0;i <= n;i++) {
		printf("Name: %s/", repo[i].name);
		printf(" Concentration: %d/", repo[i].concentration);
		printf(" Quantity: %d/", repo[i].quantity);
		printf(" Price: %d\n", repo[i].price);
	}

}
void add(struct medication *repo, int *n,char name[50],int price,int qnt,int con) {
	
	int i, ok = 0;
		for (i = 0;i <= *n;i++)
		{
			if (strcmp(repo[i].name,name)==0 && repo[i].concentration == con)
			{
				repo[i].quantity += qnt;
				ok = 1;
			}
		}
	if (ok == 0)
	{
		*n += 1;
		//printf("%s\n",name);
		strcpy(repo[*n].name, name);
		
		repo[*n].concentration = con;

		repo[*n].quantity = qnt;

		repo[*n].price = price;
	}
}
void delete(struct medication *repo, int *n, int name, int con)
{
	int i,j, ok = 0;
	for (i = 0;i <= *n&&ok==0;i++)
		if (strcmp(repo[i].name, name) == 0 && repo[i].concentration == con)
		{
			for (j = i;j < n;j++)
				repo[i] = repo[i + 1];
			ok = 1;
		}
	*n -= 1;
}
void menu() {
	printf("1. Add medication\n");
	printf("2. Delete medication\n");
	printf("3. Update medication\n");
	printf("4. Show all medications\n");
	printf("0. Exit\n");

}

struct repo {
	int repo[100];
	int n;
};
int main()
{
	struct medication repo[100];
	int n=-1,unu=1,qnt,price,con;		//n=current position
	char input,name[50];
	
	//print_all(repo, n);
	while (unu == 1)
	{
		menu();
		scanf("%c", &input);
		if (input=='1')
		{ 
			printf("Insert the medication name: ");
			scanf("%s", &name);

			printf("Insert the medication concentration: ");
			scanf("%d", &con);

			printf("Insert the medication quantity: ");
			scanf("%d", &qnt);

			printf("Insert the medication price: ");
			scanf("%d", &price);

			add(repo, &n, name, price, qnt, con);
		}
		if (input == '2')
		{
			printf("Insert the medication name you want to delete: ");
			scanf("%s", &name);

			printf("Insert the medication concentration you want to delete: ");
			scanf("%d", &con);

			delete(repo, &n, name, con);
		}
		if (input == '4')
			print_all(repo, n);
		if (input == '0')
			return 0;
	}
	
	
	
	
	scanf_s("%d", &n);
	return 0;
}